#!/bin/bash

sleep 10
 python3 /usr/src/app/donbot/run.py -c default.cfg#1 -d 10800 -m 500 -e vf -q n -p n
